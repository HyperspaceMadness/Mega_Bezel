
//#undef PARAMETER_UNIFORM

#ifndef PARAMETER_UNIFORM
//#define cropOverscan
//#define noScanlines
#define tvVerticalResolution 250.0
#define signalResolution 700.0
//#define combFilter
#define signalResolutionY 200.0
#define signalResolutionI 125.0
#define signalResolutionQ 125.0
#define blackLevel 0.07
#define contrast 1.0
#define gamma 1.0
#define phaseOffset 0.0
//#define addNoise
#define noiseStrengh 0.0
#endif
